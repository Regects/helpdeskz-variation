HelpDeskZ Repositories
======================

The HelpDeskZ is an **open source** project and repository is hosted in `Github <https://github.com/helpdesk-z/helpdeskz-dev>`_