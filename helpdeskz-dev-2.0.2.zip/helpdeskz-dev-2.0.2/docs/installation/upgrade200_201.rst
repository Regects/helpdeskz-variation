Upgrading from 2.0 to 2.0.1
===========================

The upgrade process is very simple and just upload these files:

- /index.php
- /hdz/\*.\*


Update your site
----------------

- Open **/install** in your browser, for example http://support.mysite.com/install (modify your URL).
- The HelpDeskZ setup script will run. Click `Upgrade my HelpDeskZ´ and follow the instructions through upgrade wizard.
- Thanks for using HelpDeskZ!
