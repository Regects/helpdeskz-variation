Server Requirements
====================

- PHP version 7.3 or newer is required
- **intl** extension, **mbstring** extension and **imap** extension installed.
- MySQL (5.1+) via the *MySQLi* driver