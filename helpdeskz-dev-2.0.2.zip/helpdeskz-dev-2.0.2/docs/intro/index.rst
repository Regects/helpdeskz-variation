Welcome to HelpDeskZ
====================

HelpDeskZ is a free PHP based software which allows you to manage your site's support with a web-based support ticket system.

HelpDeskZ is developed with CodeIgniter PHP framework 4